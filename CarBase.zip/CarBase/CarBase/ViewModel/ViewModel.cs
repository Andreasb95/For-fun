﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using CarBase.Annotations;
using CarBase.Model;
using Microsoft.VisualBasic.CompilerServices;

namespace CarBase.ViewModel
{
    class ViewModel : INotifyPropertyChanged
    {
        // Cars bruges til at indeholde alle de car objekter jeg har lavet.
        private ObservableCollection<Car> Cars { get; set; }

        //Car List bruges til at tilføje de objekter til en liste som vi søger efter.
        public ObservableCollection<Car> Carlist {get; set;}

        public string NumberPlate { get; set; }

        public ICommand SearchCommand { get; set; }
       

        public ViewModel()
        {
            Cars = new ObservableCollection<Car>();
            Cars.Add(new Car("XX12345", "BMW", 2007));
            Cars.Add(new Car("XX44576", "Audi", 2010));
            Cars.Add(new Car("XX88321", "VW", 1997));
            Cars.Add(new Car("XX44433", "BMW", 2005));
            Cars.Add(new Car("TT87963", "AUDI", 2005));
            Cars.Add(new Car("TT12345", "AUDI", 2004));
            Cars.Add(new Car("TT15732", "SEAT", 2005));
            Cars.Add(new Car("YY12345", "PEOGEOUT", 2018));
            Cars.Add(new Car("UU12345", "Toyota", 2020));
            Cars.Add(new Car("II12345", "Fiat", 2014));
            Cars.Add(new Car("OO12345", "Nissan", 2016));
            Cars.Add(new Car("PP12345", "Opel", 2001));
            
            
            Carlist = new ObservableCollection<Car>();

            SearchCommand = new RelayCommand(Search);
            
        }


        public void Search ()
        {
            //LINQ
            // Where er et filter som kun tager tage de car objekter der opfylder condition. I dette tilfælde er condition sat til at være propertien NumberPlate som er bindet til en tekstbox. Det betyder at condition vil være brugers input

            var carseach = from car in Cars
                where car.NumberPlate.Contains(NumberPlate)
                select car;
           
            //Carlist.Clear er for at slette listen hver gang man laver en ny søgning
            Carlist.Clear();


            //foreach for at kunne gennemløbe objekterne i listen Cars og derefter adde dem til Carlist

            foreach (var car in carseach)
            {
                Carlist.Add(car);
            }
        }

        










        #region MyRegion
        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        } 
        #endregion
    }
}
