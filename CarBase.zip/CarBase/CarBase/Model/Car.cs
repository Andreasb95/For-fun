﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBase.Model
{
    class Car
    {
        public string NumberPlate { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }

        public Car(string numberPlate, string model, int year)
        {
            NumberPlate = numberPlate;
            Model = model;
            Year = year;
        }

        public override string ToString()
        {
            return $"NumberPlate: {this.NumberPlate} \nModel {this.Model} \nYear: {this.Year}  ";
        }
    }
}
